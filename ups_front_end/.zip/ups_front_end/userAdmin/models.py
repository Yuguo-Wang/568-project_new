from django.db import models

# Create your models here.

# class myUser(models.Model):
#     userid = models.CharField(default = "", primary_key = True, max_length = 150)
#     password = models.CharField(default = "", max_length = 150)

#     def __str__(self):
#         return self.user
    
# class myUser(models.Model):
#     userid = models.CharField(default = "", primary_key = True, max_length = 150)
#     password = models.CharField(default = "", max_length = 150)
    
#     def __str__(self):
#         return self.user